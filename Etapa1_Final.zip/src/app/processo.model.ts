export interface Processo {
    isAtivo: boolean;
    descricao: string;
    codigo: string;
}